
$('document').ready(function () {
  $('.jsToggleTrigger').click(function () {
    $(this).toggleClass('_active');
  });
});

